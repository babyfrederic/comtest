<?php
// Authentification CAS
include "include/auth_cas.php";

// SERVEUR SQL
$sql_serveur="galera-cominterne.intranice.ville-nice.fr";

// LOGIN SQL
$sql_user="cominterne";

// MOT DE PASSE SQL
$sql_passwd="QSDFjk32Yp3Zq59Tqmkgkqsd";

// NOM DE LA BASE DE DONNEES
$sql_bdd="cominterne";

// username = matricule de l'agent connecté  
$username = phpCAS::getUser();
 
// CONNEXION A LA BASE DE DONNEE
$db = mysqli_connect ($sql_serveur,$sql_user,$sql_passwd);
mysqli_select_db ($db,$sql_bdd) ;

// user = matricule sous la forme de 7 chiffres     
$usersanslettre = substr($username,1); 
$user = str_pad($usersanslettre, 7, "0", STR_PAD_LEFT);

// ON RECUPERE LES NOM, PRENOM et EMAIL DE L'AGENT CONNECTE SUR SA SESSION
$requsername=mysqli_query($db, "select * from agents where matricule=\"$user\"");
$datausername = mysqli_fetch_array($requsername);

$nomusername = $datausername['nom'];
$prenomusername = $datausername['prenom'];
$emailusername = $datausername['email'];
 
$req = mysqli_query($db, "SELECT COUNT(nom) FROM agents");
$row = mysqli_fetch_array($req);
$nombre = $row['0'];

$reqdir = mysqli_query($db, "SELECT COUNT(DISTINCT direction) FROM agents");
$rowdir = mysqli_fetch_array($reqdir);
$nombredir = $rowdir['0'];

$reponse = mysqli_query($db, "SELECT DISTINCT direction FROM agents");

$reqfemmes = mysqli_query($db, 'SELECT COUNT(nom) FROM agents WHERE civilite="MME"');
$rowfemmes = mysqli_fetch_array($reqfemmes);
$nombrefemmes = $rowfemmes['0'];
  
$reqhommes = mysqli_query($db, 'SELECT COUNT(nom) FROM agents WHERE civilite="M"');
$rowhommes = mysqli_fetch_array($reqhommes);
$nombrehommes = $rowhommes['0']; 
 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="author" content="Stéphane Ventura">
    <title>Métropole NCA</title>
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.transitions.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
	
	<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="js/jquery.mobile.custom.min.js"></script>

<link type="text/css" rel="stylesheet" href="css/rotator.css" media="all" />
<link type="text/css" rel="stylesheet" href="css/custom.css" media="all" />
   <script type="text/javascript" src="js/rotator.js"></script>
</head><!--/head-->

<body id="home" class="homepage">

  <header id="header">
        <nav id="main-menu" class="navbar navbar-default navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index2.php"><img src="https://cominterne.nicecotedazur.org/images/logo.png" alt="logo"></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                         <li class="scroll"><a href="accueil.php">Accueil</a></li>
                        <li class="scroll"><a href="index2.php">Environnement professionnel</a></li>
						<li class="scroll active"><a href="transformation.php">Transformation de l'administration</a></li>
                        <li class="scroll"><a href="cominterne.php">Com'Interne</a></li>                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
    </header><!--/header-->


    <section id="main-slider">
        <div >
            <div class="item" style="background-image: url(images/slider/transformation.jpg);">
            </div><!--/.item-->
           
        </div><!--/.owl-carousel-->
    </section><!--/#main-slider-->

 
    <section id="animated-number">
        <div class="container">
            

            <div class="row text-center">
               
                <div class="col-sm-3 col-xs-6">
                    <div class="wow fadeInUp" data-wow-duration="400ms" data-wow-delay="100ms">
                        <div class="animated-number" data-digit="2800" data-duration="3000"></div>
                        <strong>TELETRAVAILLEURS</strong>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="wow fadeInUp" data-wow-duration="400ms" data-wow-delay="300ms">
                        <div class="animated-number" data-digit="179" data-duration="3000"></div>
                        <strong>KM DE PISTE CYCLABLES</strong>
                    </div>
                </div>
				<div class="col-sm-3 col-xs-6">
                    <div class="wow fadeInUp" data-wow-duration="400ms" data-wow-delay="300ms">
                        <div class="animated-number" data-digit="77000" data-duration="3000"></div>
                        <strong>ARBRES PLANTES</strong>
                    </div>
                </div>
				 <div class="col-sm-3 col-xs-6">
                    <div class="wow fadeInUp" data-wow-duration="400ms" data-wow-delay="0ms">
                        <div class="animated-number" data-digit="10" data-duration="3000"></div>
                        <strong>% REDUCTION CARBONE</strong>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/#animated-number-->
	
	<?php
	
//	while ($donnees = mysqli_fetch_array($reponse))
//	{
//		 echo $donnees['direction']; 
//		 echo "<br>";
//	}
	?>
	
	 <section id="portfolio">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title text-center wow fadeInDown">Innovations et stratégies</h2>
               
            </div>

          <!-- BEGIN of div-rotator  -->
	
<div class='div-rotator'>

<!-- Such a block as the following defines one entry. Keep the 3 div's intact  
     for each entry, they are needed for relative font-sizing (so that em works)
     The classes big, small and medium are freely defined in custom.css 
     Any kind of HTML-entry should be possible within the 3 div's. -->

<a  class='big' href="#bienetre"><img src='images/boules/boule1.png'></a>

<a  class='big' href="#transformation"><img src='images/boules/boule2.png'></a>

<a  class='medium' href="#"><img src='images/boules/boule1.png'></a>

<a  class='big' href="#"><img src='images/boules/boule1.png'></a>

<a  class='small' href="#"><img src='images/boules/boule1.png'></a>

<a  class='medium' href="#"><img src='images/boules/boule2.png'></a>

<a  class='small' href="#"><img src='images/boules/boule1.png'></a>

<a  class='small' href="#"><img src='images/boules/boule1.png'></a>

<a  class='small' href="#"><img src='images/boules/boule2.png'></a>

<a  class='medium' href="#"><img src='images/boules/boule1.png'></a>

<a  class='medium' href="#"><img src='images/boules/boule1.png'></a>

<a  class='medium' href="#"><img src='images/boules/boule2.png'></a>

<a  class='small' href="#"><img src='images/boules/boule1.png'></a>

<a  class='small' href="#"><img src='images/boules/boule2.png'></a>




</div>

<!-- END of div-rotator  -->

         
        </div><!--/.container-->
    </section><!--/#portfolio-->
	

  <?php include 'footer.php';?>	
  

    <!--<script src="js/jquery.js"></script>-->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/mousescroll.js"></script>
    <script src="js/smoothscroll.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/jquery.inview.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>